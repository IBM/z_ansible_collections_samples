.. ...........................................................................
.. © Copyright IBM Corporation 2020                                          .
.. ...........................................................................

License
=======

Some portions of this collection are licensed under
`GNU General Public License, Version 3.0`_, and other portions of this
collection are licensed under `Apache License, Version 2.0`_.

See individual files for applicable licenses.

.. _GNU General Public License, Version 3.0:
    https://opensource.org/licenses/GPL-3.0

.. _Apache License, Version 2.0:
    https://opensource.org/licenses/Apache-2.0
